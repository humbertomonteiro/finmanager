import {
  doc,
  getDoc,
  collection,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  Timestamp,
} from "firebase/firestore";
import { db } from "../../infrastructure/config/firebaseConfig";
import type { ITransactionRepository } from "../../domain/interfaces/TransactionRepositoryInterface";
import {
  Transaction,
  type TransactionProps,
} from "../../domain/entities/Transaction";

export class TransactionRepository implements ITransactionRepository {
  private readonly collectionName: string;
  constructor() {
    this.collectionName = "transactions";
  }

  cleanObject<T extends Record<string, any>>(obj: T): Partial<T> {
    return Object.fromEntries(
      Object.entries(obj).filter(([_, v]) => v !== undefined && v !== null)
    ) as Partial<T>;
  }

  async save(transaction: Transaction) {
    try {
      const transactionDTO = transaction.toDTO();

      const docRef = transaction.id
        ? doc(db, this.collectionName, transaction.id)
        : doc(collection(db, this.collectionName));

      const cleanedTransaction = this.cleanObject({
        ...transactionDTO,
        date: transactionDTO.date
          ? transactionDTO.date.toISOString()
          : new Date().toISOString(),
        updatedAt: transactionDTO.updatedAt
          ? transactionDTO.updatedAt.toISOString()
          : new Date().toISOString(),
        paidAt: transactionDTO.paidAt
          ? transactionDTO.paidAt.toISOString()
          : undefined,
      });

      await setDoc(docRef, cleanedTransaction, { merge: true });
      return docRef.id;
    } catch (error) {
      console.error("Erro ao criar transaction:", error);
      throw new Error("Error creating transaction");
    }
  }

  async getById(id: string) {
    try {
      const docRef = doc(db, this.collectionName, id);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) return null;

      const data = docSnap.data();
      return this.mapTransactionData(data, docSnap.id);
    } catch (error) {
      console.log(`Erro ao buscar documento: ${id}, erro: ${error}`);
      throw new Error("Error fetching transaction");
    }
  }

  async getAll() {
    try {
      const querySnapshot = await getDocs(collection(db, this.collectionName));

      return querySnapshot.docs.map((doc) => {
        const data = doc.data();
        return this.mapTransactionData(data, doc.id);
      });
    } catch (error) {
      console.log(`Erro so buscar transactions, erro: ${error}`);
      throw new Error(`${error}`);
    }
  }

  async update(transaction: Transaction): Promise<void> {
    try {
      if (!transaction.id)
        throw new Error("Transaction ID is required for update");
      const transactionDTO = transaction.toDTO();

      const docRef = doc(db, this.collectionName, transaction.id);

      const cleanedDTO = this.cleanObject({
        ...transactionDTO,
        paidAt: transactionDTO.paidAt
          ? transactionDTO.paidAt.toISOString()
          : undefined,
      });
      await updateDoc(docRef, cleanedDTO);
    } catch (error) {
      console.error(`Error updating transaction ${transaction.id}:`, error);
      throw new Error("Error updating transaction");
    }
  }

  async markAsPaid(id: string): Promise<void> {
    try {
      const docRef = doc(db, this.collectionName, id);
      await updateDoc(docRef, {
        isPaid: true,
        paidAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    } catch (error) {
      console.error(`Error marking transaction ${id} as paid:`, error);
      throw new Error("Error marking transaction as paid");
    }
  }

  async delete(id: string): Promise<void> {
    try {
      const docRef = doc(db, this.collectionName, id);
      await deleteDoc(docRef);
    } catch (error) {
      console.error(`Error deleting transaction ${id}:`, error);
      throw new Error("Error deleting transaction");
    }
  }

  private mapTransactionData(data: any, id: string): Transaction {
    const date =
      data.date instanceof Timestamp
        ? data.date.toDate()
        : new Date(data.date ?? Date.now());

    const updatedAt =
      data.updatedAt instanceof Timestamp
        ? data.updatedAt.toDate()
        : new Date(data.updatedAt ?? Date.now());

    const paidAt = data.paidAt
      ? data.paidAt instanceof Timestamp
        ? data.paidAt.toDate()
        : new Date(data.paidAt)
      : undefined;

    return new Transaction({
      ...data,
      id,
      date,
      updatedAt,
      paidAt,
    } as TransactionProps);
  }
}
